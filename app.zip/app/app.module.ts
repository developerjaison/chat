import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { MenuComponent } from './sharedModules/menu/menu.component';
import { chatDetailsComponent } from './sharedModules/chatDetails/chatDetails.component';

@NgModule({
  declarations: [
    AppComponent,
    MenuComponent,
    chatDetailsComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
