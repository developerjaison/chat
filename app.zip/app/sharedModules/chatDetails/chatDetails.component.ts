import { Component } from '@angular/core';

@Component({
  selector: 'chat-details',
  templateUrl: './chatDetails.component.html',
  styleUrls: ['./chatDetails.component.css']
})
export class chatDetailsComponent {
  
}