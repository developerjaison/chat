import { Component, OnInit, Input } from '@angular/core';
import { Location } from '@angular/common';

@Component({
  selector: 'app-footer-detail',
  templateUrl: './footer.component.html',
  styleUrls: [ './footer.component.css' ]
})
export class footerComponent implements OnInit{

    private pagetitle:String

    cunstructor(){

    }

    ngOnInit():void{
        this.pagetitle = "Chat";
    }
}