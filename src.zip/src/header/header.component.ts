import { Component, OnInit, Input } from '@angular/core';
import { Location } from '@angular/common';

@Component({
  selector: 'app-header-detail',
  templateUrl: './header.component.html',
  styleUrls: [ './header.component.css' ]
})
export class headerComponent implements OnInit{

    private pagetitle:String

    cunstructor(){

    }

    ngOnInit():void{
        this.pagetitle = "Chat";
    }
}